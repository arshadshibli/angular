import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { WishListComponent } from './wish-list/wish-list.component';
import { RoutingModule, routingComponents } from './routing/routing.module';
import {HttpClientModule} from '@angular/common/http';
import { MovieComponent } from './service/movie/movie.component';
import { MovieFormComponent } from './component/movie-form/movie-form.component';
@NgModule({
  declarations: [
    AppComponent,
    MovieListComponent,
    WishListComponent,
    MovieComponent,
    MovieFormComponent
  ],
  imports: [
    BrowserModule,RoutingModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent,routingComponents]
})
export class AppModule { }
