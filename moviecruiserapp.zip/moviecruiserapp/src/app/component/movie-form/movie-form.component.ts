import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IMovie } from 'src/app/movie';
import { MovieService } from 'src/app/service/movie.service';
import { InputService } from 'src/app/input.service';
import { ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-movie-form',
  templateUrl: './movie-form.component.html',
  styleUrls: ['./movie-form.component.css']
})
export class MovieFormComponent implements OnInit {
  private id;
  private url = "http://localhost:8080/api/v1";
  movie:IMovie={
    "imdbId":"defay",
    "movieTitle": "spadikam",
    "yearOfRelease": "2018",
    "rating": 4.5,
    "comment": "Thrilling Experience",
    "posterUrl": "https://m.media-amazon.com/images/M/MV5BNTU3ZjEzMTYtYThjMC00ZjljLNzA@._V1_QL50_SY1000__.jpg"
  };
  constructor(private http:HttpClient,private movieService:MovieService,private inputservice:InputService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      let id = params.get('id');
      this.id = id;
    });
    this.addMovie();
  }
  addMovie() {
    this.inputservice.getMovie(this.id).subscribe((data) => {
      this.movie.imdbId=data["imdbID"];
      this.movie.movieTitle=data["Title"];
      this.movie.yearOfRelease=data["Year"];
      console.log("inside for component data is ", this.movie);
      console.log("init");
    });
  }
  saveMovie(id:string,title:string,year:string,rating:number,url:string,comment:string)
  {
    console.log("save movie called");
    this.movie.imdbId=id;
    this.movie.movieTitle=title;
    this.movie.yearOfRelease=year;
    this.movie.rating=rating;
    this.movie.posterUrl=url;
    this.movie.comment=comment;
    console.log(this.movie);
    this.movieService.postMovie(this.url,this.movie);
  }

}