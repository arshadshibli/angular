import { Component, OnInit, Input } from '@angular/core';
import { InputService } from '../input.service';
import { ActivatedRoute, ParamMap, Route, Router } from '@angular/router';
import { IMovieIn } from '../moviein';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {

  public searchTitle;
  public moviesMatching: IMovieIn[];
  constructor(private inputservice: InputService, private route: ActivatedRoute,private router:Router) { }

  ngOnInit() {
    console.log("init called")
    this.route.paramMap.subscribe((params: ParamMap) => {
      let title = params.get('title');
      this.searchTitle = title;
    });
    this.searchMovie();
  }
  searchMovie() {
    this.inputservice.searchMovie(this.searchTitle).subscribe((data) => {
      this.moviesMatching = data['Search'];
      console.log("inside component data is ", this.moviesMatching);
      console.log("init");
    });
  }
  addMovie(id:string)
  {
    console.log("add movie in movie list");
    this.router.navigate([id],{relativeTo:this.route})
  }

}
