export  interface IMovie
{
    imdbId:string;
    movieTitle:string;
    yearOfRelease:string;
    rating:number;
    comment:string;
    posterUrl:string;
}