import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { CommonModule } from '@angular/common';
import { MovieListComponent } from '../movie-list/movie-list.component';
import { WishListComponent } from '../wish-list/wish-list.component';
import { MovieFormComponent } from '../component/movie-form/movie-form.component';
const routes:Routes=[
  {path:'movies/:title',component:MovieListComponent,
children:[{path:':id',component:MovieFormComponent}]
},
  {path:'wishList',component:WishListComponent}
]
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class RoutingModule { }
export const routingComponents=[MovieListComponent,WishListComponent,MovieFormComponent]
