import { Component, OnInit } from '@angular/core';
import { InputService } from '../input.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { MovieService } from '../service/movie.service';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.component.html',
  styleUrls: ['./wish-list.component.css']
})
export class WishListComponent implements OnInit {
  public movies = [];
  
  constructor(private movieservice:MovieService) { }

  ngOnInit() {
    this.movieservice.getMovies()
    .subscribe(data => this.movies = data);
  }

  deleteMovie(id:string)
  {
    console.log("deleteMobie  in list");
    this.movieservice.deleteMovie(id);
  }
  updateMovie(id:string,comment:string)
  {
    console.log("updatee Mobie  in list");
    this.movieservice.updateMovie(id,comment);
  }

}
